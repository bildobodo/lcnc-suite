/** <Typr Font Parser>.init **/

troikaDefine(
function init(s,e,t){const i=s(),n=e();return t(i,n)}
)